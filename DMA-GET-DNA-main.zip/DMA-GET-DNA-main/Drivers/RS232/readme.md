1. Open ZADlG.exe.
2. Click on Options > List All Devices.
3. Click on RS232-HS（interface 0-5)
4. Replace or install driver.