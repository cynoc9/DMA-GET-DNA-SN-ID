Click on CH341PAR > SETUP.EXE to install driver
/or
Right-click CH341WDM.INF > install to install driver
